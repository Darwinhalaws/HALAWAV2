import fetch from 'node-fetch'
let handler = async(m, { conn, text, usedPrefix, command }) => {
let pp = await conn.profilePictureUrl(m.chat).catch(_ => null)

let krtu = `0ཻུ۪۪ꦽꦼ̷⸙‹•══════════════♡᭄
│       「 Kartu Intro 」
│ Nama     : 
│ Gender   : 
│ Umur      : 
│ Hobby    : 
│ Kelas      : 
│ Asal         : 
|  Status     : 
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
`
m.reply(krtu)
}
  handler.help = ['intro']
  handler.tags = ['main']
  handler.command = /^(intro)$/i
  
  export default handler